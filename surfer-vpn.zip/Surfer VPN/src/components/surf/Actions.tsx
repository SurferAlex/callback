import { openLink, haptic } from '@/lib/telegram';
import { buildHappUrl } from '@/lib/constants';
import { Ic } from '@/components/surf/icons';

export function Actions({ vpnKey, onCopy }: { vpnKey: string; onCopy: () => void }) {
  const openHapp = () => {
    openLink(buildHappUrl(vpnKey));
    haptic('medium');
  };
  return (
    <section className="actions">
      <button className="btn-primary" onClick={openHapp}>
        <span className="btn-primary-shine"></span>
        <span className="btn-primary-label">
          <span className="btn-primary-title">Открыть Happ</span>
          <span className="btn-primary-desc">Подключиться в один тап</span>
        </span>
        <span className="btn-primary-arrow"><Ic.Arrow /></span>
      </button>
      <button className="btn-ghost" onClick={onCopy}>
        <Ic.Copy /><span>Скопировать ключ</span>
      </button>
    </section>
  );
}
