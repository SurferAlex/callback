import type { User } from "@/types";
import { MOCK_USER, daysUntil } from "@/lib/mock-data";
import { getTelegramUser } from "@/lib/telegram";

/**
 * Thin API layer. Today it returns mock data merged with the real Telegram
 * identity. When the backend is ready, swap the body of `getCurrentUser`
 * for a `fetch` against `API_BASE_URL` using `initData` for auth — the rest
 * of the app (hooks, components) depends only on the `User` shape, so no
 * UI changes will be required.
 */

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? "https://api.surfervpn.com";

/** Simulate network latency so loading states are exercised in dev. */
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Fetch the current user. Currently mock-backed:
 * overlays the live Telegram identity (id / name / username / avatar) on top
 * of the mock subscription + server + VPN key, and recomputes `daysLeft`.
 *
 * Future: replace with
 *   const res = await fetch(`${API_BASE_URL}/me`, {
 *     headers: { Authorization: `tma ${getWebApp()?.initData}` },
 *   });
 *   return (await res.json()) as User;
 */
export async function getCurrentUser(): Promise<User> {
  await delay(600);

  const tg = getTelegramUser();
  const base = MOCK_USER;

  return {
    ...base,
    telegramId: tg?.id ?? base.telegramId,
    firstName: tg?.first_name ?? base.firstName,
    lastName: tg?.last_name ?? base.lastName,
    username: tg?.username ?? base.username,
    photoUrl: tg?.photo_url ?? base.photoUrl,
    subscription: {
      ...base.subscription,
      daysLeft: daysUntil(base.subscription.expiresAt),
    },
  };
}

/**
 * Fetch the user's VPN key. Mock returns the key embedded in the user.
 * Future: GET `${API_BASE_URL}/key`.
 */
export async function getVpnKey(): Promise<string> {
  const user = await getCurrentUser();
  return user.vpnKey;
}
