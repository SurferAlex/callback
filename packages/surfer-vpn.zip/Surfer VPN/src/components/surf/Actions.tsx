import { openHappUrl, haptic } from '@/lib/telegram';
import { Ic } from '@/components/surf/icons';

export function Actions({
  vpnKey,
  onRefresh,
  refreshing,
}: {
  vpnKey: string;
  onRefresh?: () => void;
  refreshing?: boolean;
}) {
  const openHapp = () => {
    if (!vpnKey.trim()) return;
    haptic('medium');
    openHappUrl(vpnKey);
  };
  return (
    <section className="actions">
      <button className="btn-primary" onClick={openHapp}>
        <span className="btn-primary-shine"></span>
        <span className="btn-primary-label">
          <span className="btn-primary-title">Открыть Happ</span>
          <span className="btn-primary-desc">Подключиться в один тап</span>
        </span>
        <span className="btn-primary-arrow"><Ic.Arrow /></span>
      </button>
      {onRefresh && (
        <button
          type="button"
          className={"btn-refresh" + (refreshing ? " is-loading" : "")}
          onClick={onRefresh}
          disabled={refreshing}
        >
          <span className="btn-refresh-icon" aria-hidden="true">
            <Ic.Refresh size={20} />
          </span>
          <span>{refreshing ? "Обновляем…" : "Обновить конфиг"}</span>
        </button>
      )}
    </section>
  );
}
